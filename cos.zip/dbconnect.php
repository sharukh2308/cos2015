<?php
$host="localhost";

$mysql_db = "itrix15db"; 
$mysql_u = "rootwebster";
$mysql_p =  "Ista-2015";

 $con=mysqli_connect("$host","$mysql_u","$mysql_p","$mysql_db");
?>