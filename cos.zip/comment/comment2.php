<html> 
<head>

<meta property="fb:app_id" content="706718599447644"/> 

</head>
<body>
<a href="http://www.itrix.in">Click here</a> to go to game </body>
</html>