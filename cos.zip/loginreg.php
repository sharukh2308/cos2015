<div style="display:none" id="loginreg">  
    <div class="tab-content">
        <div class="tab-pane fade in active" id="t1">
            <center>
            	<input type="text" id="email" placeholder="email" class="form-controls" style="height:10%" /><br/>
            	<input type="text" id="iid" placeholder="itrixID" class="form-controls" style="height:10%"/><br/>
            	<button id="loginbtn" type="Submit" class="btn btn-primary">Login</button>
            	<button id="registerbtn" class="btn btn-danger" style="margin-left: 1%">Register</button>
            </center> 
    	</div>
	</div>
</div>