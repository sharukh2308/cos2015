<script>
	window.location='..\\..\\';
</script>