<?php
	session_start();
	if($_SESSION['level']>=7){
		echo "<div style='height:270px;opacity:1'>
		<div id='divq51' style='height:100%;width:14.28%;background-color:white;float:left'></div>
		<div id='divq52' style='height:100%;width:14.28%;background-color:white;float:left'></div>
		<div id='divq53' style='height:100%;width:14.28%;background-color:white;float:left'></div>
		<div id='divq54' style='height:100%;width:14.28%;background-color:white;float:left'></div>
		<div id='divq55' style='height:100%;width:14.28%;background-color:white;float:left'></div>
		<div id='divq56' style='height:100%;width:14.28%;background-color:white;float:left'></div>
		<div id='divq57' style='height:100%;width:14.28%;background-color:white;float:left'></div>
		</div>";
	}
?>

<script src="js/q5php.js"></script>