<?php
	session_start();
	
		echo "<div style='height:100%'>";
		echo "<div style='float:left'>
		<img src='qimg/img/welcome.jpg'/>
		</div>
		</div>";
	
?>