<?php 
session_start();
echo '<html xmlns:fb="http://ogp.me/ns/fb#"><body>';
echo '<div class="fb-comments" data-href="http://cos.itrix.in/comment/comment'.$_SESSION['level'].'.php" data-numposts="5" data-colorscheme="dark"></div>'; ?>